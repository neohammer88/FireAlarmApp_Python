/* Title : FireNot App
 * Version : 1.2
 * Language : Android Studio
 * Programmer : Tom Rho
 * Date : 09/12/2017
 */
package com.example.tg.firenot;

/**
 * Created by TG on 2017-09-13.
 */

public class User {
    public String name;
    public String email;
    public String token;

    //Make a vacant constructor.
    //DataSnapshot.getValue(User.class)
    public User() {

    }

    //Receive a user information
    public User(String name, String email, String token) {
        this.name = name;
        this.email = email;
        this.token = token;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getToken() {
        return token;
    }

}
