/* Title : FireNot App
 * Version : 1.2
 * Language : Android Studio
 * Programmer : Tom Rho
 * Date : 09/12/2017
 */
package com.example.tg.firenot;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import java.io.IOException;

/**
 * Created by TG on 2017-09-12.
 */


public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {
    private static final String TAG = "MyFirebaseIIDService";

    // [START refresh_token]
    @Override
    public void onTokenRefresh() {
        // Get updated InstanceID token.
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG, "Refreshed token: " + refreshedToken);

        storeToken(refreshedToken);
    }

    //Save token
    private void storeToken(String token){
        SharedPrefManager.getInstance(getApplicationContext()).saveDeviceToken(token);
    }
}
