package com.example.tg.firenot;

import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

// Alarm activity
public class AlarmActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
    }

    public void mapLocation (View aView)
    {
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }
}
